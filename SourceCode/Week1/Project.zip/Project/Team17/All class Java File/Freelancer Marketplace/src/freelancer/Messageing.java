package freelancer;

public class Message {
    private String messageId;
    private String messageSender; // Can be either Client or Freelancer
    private String messageReceiver; // Can be either Client or Freelancer
    private String message;
    private int timestamp;
    // Constructors, getters, setters
}

