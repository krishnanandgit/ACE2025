package freelancer;

public class Client {
    private int clientId;
    private String clientUsername;
    private String clientPassword;
    private String clientEmail;
    
}
