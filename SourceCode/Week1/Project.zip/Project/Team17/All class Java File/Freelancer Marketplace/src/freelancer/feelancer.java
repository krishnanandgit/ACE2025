package freelancer;

import java.util.Scanner;

public class feelancer {
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the freelancer_id");
		System.out.println("Enter the name");
		
		
		
	}

}
