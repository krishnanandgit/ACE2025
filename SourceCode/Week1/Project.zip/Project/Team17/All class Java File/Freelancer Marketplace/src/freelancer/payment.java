package freelancer;

public class Payment {
    private int paymentId;
    private String freelancerId;
    private String clientId;
    private double amount;
    private int date;
    // Constructors, getters, setters
}
