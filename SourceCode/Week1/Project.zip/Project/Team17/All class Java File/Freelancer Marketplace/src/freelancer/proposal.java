package freelancer;

public class Proposal {
    private int proposalId;
    private double proposalBidamount;
    private String freelancerId;;
    private String projectId;
    private String proposalstatus;
    // Constructors, getters, setters
}
